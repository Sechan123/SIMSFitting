function varargout = SIMSFitting(varargin)
% SIMSFITTING MATLAB code for SIMSFitting.fig
%      SIMSFITTING, by itself, creates a new SIMSFITTING or raises the existing
%      singleton*.
%
%      H = SIMSFITTING returns the handle to a new SIMSFITTING or the handle to
%      the existing singleton*.
%
%      SIMSFITTING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SIMSFITTING.M with the given input arguments.
%
%      SIMSFITTING('Property','Value',...) creates a new SIMSFITTING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SIMSFitting_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SIMSFitting_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SIMSFitting

% Last Modified by GUIDE v2.5 07-Feb-2019 19:29:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SIMSFitting_OpeningFcn, ...
                   'gui_OutputFcn',  @SIMSFitting_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SIMSFitting is made visible.
function SIMSFitting_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SIMSFitting (see VARARGIN)

% Choose default command line output for SIMSFitting
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
initialize_gui(hObject, handles, false);

% UIWAIT makes SIMSFitting wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = SIMSFitting_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in reset.
function reset_Callback(hObject, eventdata, handles)
% hObject    handle to reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

initialize_gui(gcbf, handles, true);

function initialize_gui(fig_handle, handles, isreset)
% If the metricdata field is present and the reset flag is false, it means
% we are we are just re-initializing a GUI by calling it from the cmd line
% while it is up. So, bail out as we dont want to reset the data.

if isfield(handles, 'pardata') && ~isreset
    return;
end

if isfield(handles, 'simsdatafile') && ~isreset
    return;
end

handles.pardata.par1 = 8.3;
handles.pardata.par2 = 1.0128;
handles.pardata.par3 = 0.8847;
handles.pardata.par4 = 7.0;
handles.pardata.par5 = 21.21;

handles.pardata.par1lb = 8.2;
handles.pardata.par2lb = 1.00;
handles.pardata.par3lb = 0.88;
handles.pardata.par4lb = 6.9999;
handles.pardata.par5lb = 21.11;

handles.pardata.par1ub = 8.4;
handles.pardata.par2ub = 1.02;
handles.pardata.par3ub = 0.89;
handles.pardata.par4ub = 7.0001;
handles.pardata.par5ub = 21.31;

handles.fittingoption.TolFun = 1e+36;
handles.fittingoption.MaxFunEvals = 1000;

handles.simsdatafiledir = 'Default Dir';

handles.simssplit3.sp1stcut = 500.0;
handles.simssplit3.sp2ndcut = 1000.0;

set(handles.Par1, 'String', handles.pardata.par1);
set(handles.Par2, 'String', handles.pardata.par2);
set(handles.Par3, 'String', handles.pardata.par3);
set(handles.Par4, 'String', handles.pardata.par4);
set(handles.Par5, 'String', handles.pardata.par5);

set(handles.Par1lb, 'String', handles.pardata.par1lb);
set(handles.Par2lb, 'String', handles.pardata.par2lb);
set(handles.Par3lb, 'String', handles.pardata.par3lb);
set(handles.Par4lb, 'String', handles.pardata.par4lb);
set(handles.Par5lb, 'String', handles.pardata.par5lb);

set(handles.Par1ub, 'String', handles.pardata.par1ub);
set(handles.Par2ub, 'String', handles.pardata.par2ub);
set(handles.Par3ub, 'String', handles.pardata.par3ub);
set(handles.Par4ub, 'String', handles.pardata.par4ub);
set(handles.Par5ub, 'String', handles.pardata.par5ub);

handles.flag_fitting = 0;
handles.flag_SIMSDir_Selected = 0;

% Update handles structure
guidata(handles.figure1, handles);

% --- Executes on button press in pushbuttonSIMSDataDir.
function pushbuttonSIMSDataDir_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonSIMSDataDir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sbuff = strcat(pwd,'/SIMSDB');
SIMSDATAFileDir = uigetdir(sbuff);
handles.simsdatafiledir = SIMSDATAFileDir;
SIMSDATAFileDir = strcat(SIMSDATAFileDir,'/');

SIMSDataFilePath = strcat(SIMSDATAFileDir,'*.txt');
SIMSDataFile = dir(SIMSDataFilePath);
nSIMSDataFile = length(SIMSDataFile);

for i = 1:nSIMSDataFile
    [SIMSDataFile(i).sfilename rem] = strtok(SIMSDataFile(i).name,'.');
    [str rem ] = strtok(SIMSDataFile(i).sfilename,'_');
    [SIMSDataFile(i).WPInfo rem ] = strtok(rem,'_');
    [SIMSDataFile(i).AnnTemptInfo rem] = strtok(rem,'_');
    [SIMSDataFile(i).DataSetInfo rem] = strtok(rem,'_');
    [str rem] = strtok(rem,'_');
    [SIMSDataFile(i).AnnealTimeInfo rem] = strtok(rem,'_');
end

SIMSDataSet = '';
sDataSet = '';
j = 0;
nSIMSDataFile;

for i = 1:nSIMSDataFile
    if (findstr('Noanneal',SIMSDataFile(i).AnnealTimeInfo))
        j = j + 1;
        SIMSDataSet(j).AsGrownFilename = SIMSDataFile(i).name;
        SIMSDataSet(j).AsGrownFileIdx = i;
        sDataSet = SIMSDataFile(i).DataSetInfo;
        SIMSDataSet(j).DataSetInfo = sDataSet;
        SIMSDataSet(j).AnnTemptInfo = SIMSDataFile(i).AnnTemptInfo;
        SIMSDataSet(j).WPInfo = SIMSDataFile(i).WPInfo;
    end
end

numDataSet = length(SIMSDataSet);

for j = 1:numDataSet
    k = 0;
    for i = 1:nSIMSDataFile
        if(findstr(SIMSDataSet(j).DataSetInfo,SIMSDataFile(i).DataSetInfo))
              k = k + 1;
            SIMSDataSet(j).AnnealFileIdx(k) = i;
            SIMSDataSet(j).AnnealFilename{k} = SIMSDataFile(i).sfilename;
            rem = SIMSDataSet(j).AnnealFilename{k};
            for kk = 1:5
                [token, rem] = strtok(rem,'_');
            end
            [token, rem] = strtok(rem,'_');
            if(isempty(findstr('Noanneal',SIMSDataFile(i).AnnealTimeInfo)))
                [token, rem] = strtok(token,'s');
                nAnnealT = str2num(token);
                SIMSDataSet(j).AnnealT(k).val = str2num(token);
                SIMSDataSet(j).AnnealT(k).idx = k;
            else
                % if Noanneal
                SIMSDataSet(j).AnnealT(k).val = 0;
                SIMSDataSet(j).AnnealT(k).idx = k;
            end
        end
    end

    for idxAF=1:length(SIMSDataSet(j).AnnealFilename)
        for jdxAF=1:length(SIMSDataSet(j).AnnealFilename)-1
            if ( SIMSDataSet(j).AnnealT(jdxAF).val > ...
                    SIMSDataSet(j).AnnealT(jdxAF+1).val )
                temp = SIMSDataSet(j).AnnealT(jdxAF).val;
                SIMSDataSet(j).AnnealT(jdxAF).val = ...
                    SIMSDataSet(j).AnnealT(jdxAF+1).val;
                SIMSDataSet(j).AnnealT(jdxAF+1).val = temp;
                temp = SIMSDataSet(j).AnnealFilename{jdxAF};
                SIMSDataSet(j).AnnealFilename{jdxAF} = ...
                    SIMSDataSet(j).AnnealFilename{jdxAF+1};
                SIMSDataSet(j).AnnealFilename{jdxAF+1} = temp;
            end
        end
    end
end
handles.simsdatafile = SIMSDataFile;
handles.simsdataset = SIMSDataSet;
for i=1:length(handles.simsdataset)
sDataSetList{i} = handles.simsdataset(i).DataSetInfo;
end
set(handles.popupmenuSIMSDataSet,'String',sDataSetList,...
    'Value',1);
msgbox('SIMS Data File Reading Done','SIMS Data Message');
guidata(hObject,handles)


function editTolFun_Callback(hObject, eventdata, handles)
% hObject    handle to editTolFun (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editTolFun as text
%        str2double(get(hObject,'String')) returns contents of editTolFun as a double
TolFun = str2double(get(hObject, 'String'));
if isnan(TolFun)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end
% Save the new Par1 value
handles.fittingoption.TolFun = TolFun;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function editTolFun_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editTolFun (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editMaxFunEvals_Callback(hObject, eventdata, handles)
% hObject    handle to editMaxFunEvals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editMaxFunEvals as text
%        str2double(get(hObject,'String')) returns contents of editMaxFunEvals as a double
MaxFunEvals = str2double(get(hObject, 'String'));
if isnan(MaxFunEvals)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end
% Save the new Par1 value
handles.fittingoption.MaxFunEvals = MaxFunEvals;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function editMaxFunEvals_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editMaxFunEvals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par1_Callback(hObject, eventdata, handles)
% hObject    handle to Par1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String'po) returns contents of Par1 as text
%        str2double(get(hObject,'String')) returns contents of Par1 as a double
par1 = str2double(get(hObject, 'String'));
if isnan(par1)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par1 = par1;
guidata(hObject,handles)



% --- Executes during object creation, after setting all properties.
function Par1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Par1lb_Callback(hObject, eventdata, handles)
% hObject    handle to Par1lb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par1lb as text
%        str2double(get(hObject,'String')) returns contents of Par1lb as a double
par1lb = str2double(get(hObject, 'String'));
if isnan(par1lb)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par1lb = par1lb;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par1lb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par1lb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenuSIMSDataSet.
function popupmenuSIMSDataSet_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuSIMSDataSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenuSIMSDataSet contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuSIMSDataSet
handles.flag_SIMSDir_Selected = 1;
val = get(hObject,'Value');
string_list = get(hObject,'String');
handles.selectedDSidx = val;
handles.simsdataset(val).AsGrownFilename;
strbuff = strcat('As Grown: ', handles.simsdataset(val).AsGrownFilename);
set(handles.editAsGrown,'String',strbuff,...
    'Value',1);

sDataSetList = handles.simsdataset(val).AnnealFilename;
set(handles.listboxSIMSDataSet,'String',sDataSetList,...
    'Value',1);

sbuff = strcat('SIMS_', ...
    handles.simsdataset(handles.selectedDSidx).WPInfo,'_',...
    handles.simsdataset(handles.selectedDSidx).AnnTemptInfo,'_',...
    handles.simsdataset(handles.selectedDSidx).DataSetInfo,'_', ...
    'WInfo.log');
sbuff = strcat('./FittingDB/',sbuff);
fid = fopen(sbuff);
if (fid == -1)
    msgbox('Warning: no WInfo file');
else
fgetl(fid);
i = 1;
while 1
    tline = fgetl(fid);
    if ~ischar(tline), break, end
    [sbuff rem] = strtok(tline,' ');
    handles.simsdataset(val).WInfoAT{i} = sbuff;
    handles.simsdataset(val).WInfo{i} = str2num(rem);
    i = i + 1;
end
fclose(fid);
end

% Create frequency plot
axes(handles.axesbf)
sbuff = strcat(handles.simsdatafiledir,'/',...
    handles.simsdataset(val).AsGrownFilename);
ADAT = load(sbuff);
handles.selectedADAT = ADAT;
ADAT(:,2) = ADAT(:,2) + 1e10;
XA = ADAT(:,1);
CA = ADAT(:,2);
h = zeros(1,1);
h(1) = semilogy(XA,CA,'b');
legend(h, 'As Grown');
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function popupmenuSIMSDataSet_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuSIMSDataSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editAsGrown_Callback(hObject, eventdata, handles)
% hObject    handle to editAsGrown (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editAsGrown as text
%        str2double(get(hObject,'String')) returns contents of editAsGrown as a double


% --- Executes during object creation, after setting all properties.
function editAsGrown_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editAsGrown (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in listboxSIMSDataSet.
function listboxSIMSDataSet_Callback(hObject, eventdata, handles)
% hObject    handle to listboxSIMSDataSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listboxSIMSDataSet contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listboxSIMSDataSet
if (handles.flag_SIMSDir_Selected == 1)
contents = get(hObject,'String');
selfn0 = contents{get(hObject,'Value')};
handles.selectedANFN = selfn0;
if (findstr('Noanneal',handles.selectedANFN))
    handles.selectedAnnealTime = '0s';
else
    [sbuff rem ] = strtok(selfn0,'_');
    [sbuff rem ] = strtok(rem,'_');
    [sbuff rem] = strtok(rem,'_');
    [sbuff rem] = strtok(rem,'_');
    [sbuff rem] = strtok(rem,'_');
    [handles.selectedAnnealTime rem] = strtok(rem,'_');
end
selfn = strcat(selfn0,'.txt');
val = handles.selectedDSidx;
axes(handles.axesbf);
sbuff = strcat(handles.simsdatafiledir,'\',...
    handles.simsdataset(val).AsGrownFilename);
ADAT = handles.selectedADAT;
ADAT(:,2) = ADAT(:,2) + 1e10;
XA = ADAT(:,1);
CA = ADAT(:,2);
h = zeros(2,1);
h(1) = semilogy(XA,CA,'b');
hold on
sbuff = strcat(handles.simsdatafiledir,'/', ...
    selfn);
BDAT = load(sbuff);
handles.selectedBDAT = BDAT;
BDAT(:,2) = BDAT(:,2) + 1e10;
XB_DATA = BDAT(:,1);
CB_DATA = BDAT(:,2);
h(2) = semilogy(XB_DATA,CB_DATA,'b+');
legend(h, 'As Grown', 'After Annealing');
hold off

sbuff = strcat('./FittingDB/*',selfn0,'*.*');
files = dir(sbuff);
if(length(files) > 0)
    sFittingDBList = [];
    for i=1:length(files)
        sFittingDBList = strvcat(sFittingDBList,files(i).name);
    end
%    set(handles.listboxDSFittingResult,'String',sFittingDBList,...
%        'Value',1);
else
%    set(handles.listboxDSFittingResult,'String','',...
%        'Value',1);
end
guidata(hObject,handles)
else 
    errordlg('   No SIMS Directory is selected', 'Error')
end

% --- Executes during object creation, after setting all properties.
function listboxSIMSDataSet_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listboxSIMSDataSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par1ub_Callback(hObject, eventdata, handles)
% hObject    handle to Par1ub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par1ub as text
%        str2double(get(hObject,'String')) returns contents of Par1ub as a double
par1ub = str2double(get(hObject, 'String'));
if isnan(par1ub)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par1ub = par1ub;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par1ub_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par1ub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par2_Callback(hObject, eventdata, handles)
% hObject    handle to Par2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par2 as text
%        str2double(get(hObject,'String')) returns contents of Par2 as a double
par2 = str2double(get(hObject, 'String'));
if isnan(par2)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par2 = par2;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par3_Callback(hObject, eventdata, handles)
% hObject    handle to Par3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par3 as text
%        str2double(get(hObject,'String')) returns contents of Par3 as a double
par3 = str2double(get(hObject, 'String'));
if isnan(par3)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end
% Save the new Par1 value
handles.pardata.par3 = par3;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par4_Callback(hObject, eventdata, handles)
% hObject    handle to Par4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par4 as text
%        str2double(get(hObject,'String')) returns contents of Par4 as a double
par4 = str2double(get(hObject, 'String'));
if isnan(par4)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par4 = par4;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par5_Callback(hObject, eventdata, handles)
% hObject    handle to Par5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par5 as text
%        str2double(get(hObject,'String')) returns contents of Par5 as a double
par5 = str2double(get(hObject, 'String'));
if isnan(par5)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par5 = par5;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par5_CreateFcn(hObject, Par1lb_Callbackeventdata, handles)
% hObject    handle to Par5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par2lb_Callback(hObject, eventdata, handles)
% hObject    handle to Par2lb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par2lb as text
%        str2double(get(hObject,'String')) returns contents of Par2lb as a double

par2lb = str2double(get(hObject, 'String'));
if isnan(par2lb)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par1lb = par2lb;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par2lb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par2lb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par2ub_Callback(hObject, eventdata, handles)
% hObject    handle to Par2ub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par2ub as text
%        str2double(get(hObject,'String')) returns contents of Par2ub as a double
par2ub = str2double(get(hObject, 'String'));
if isnan(par2ub)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par1ub = par2ub;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par2ub_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par2ub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par3ub_Callback(hObject, eventdata, handles)
% hObject    handle to Par3ub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par3ub as text
%        str2double(get(hObject,'String')) returns contents of Par3ub as a double

par3ub = str2double(get(hObject, 'String'));
if isnan(par3ub)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par3ub = par3ub;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par3ub_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par3ub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par3lb_Callback(hObject, eventdata, handles)
% hObject    handle to Par3lb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par3lb as text
%        str2double(get(hObject,'String')) returns contents of Par3lb as a double
par3lb = str2double(get(hObject, 'String'));
if isnan(par3lb)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par3lb = par3lb;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par3lb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par3lb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par4lb_Callback(hObject, eventdata, handles)
% hObject    handle to Par4lb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par4lb as text
%        str2double(get(hObject,'String')) returns contents of Par4lb as a double

par4lb = str2double(get(hObject, 'String'));
if isnan(par4lb)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par4lb = par4lb;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par4lb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par4lb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par4ub_Callback(hObject, eventdata, handles)
% hObject    handle to Par4ub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par4ub as text
%        str2double(get(hObject,'String')) returns contents of Par4ub as a double
par4ub = str2double(get(hObject, 'String'));
if isnan(par4ub)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par4ub = par4ub;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par4ub_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par4ub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par5lb_Callback(hObject, eventdata, handles)
% hObject    handle to Par5lb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par5lb as text
%        str2double(get(hObject,'String')) returns contents of Par5lb as a double
par5lb = str2double(get(hObject, 'String'));
if isnan(par5lb)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par5lb = par5lb;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par5lb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par5lb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Par5ub_Callback(hObject, eventdata, handles)
% hObject    handle to Par5ub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Par5ub as text
%        str2double(get(hObject,'String')) returns contents of Par5ub as a double
par5ub = str2double(get(hObject, 'String'));
if isnan(par5ub)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new Par1 value
handles.pardata.par5ub = par5ub;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Par5ub_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Par5ub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editNewPar1_Callback(hObject, eventdata, handles)
% hObject    handle to editNewPar1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editNewPar1 as text
%        str2double(get(hObject,'String')) returns contents of editNewPar1 as a double

% --- Executes during object creation, after setting all properties.
function editNewPar1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editNewPar1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editNewPar2_Callback(hObject, eventdata, handles)
% hObject    handle to editNewPar2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editNewPar2 as text
%        str2double(get(hObject,'String')) returns contents of editNewPar2 as a double

% --- Executes during object creation, after setting all properties.
function editNewPar2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editNewPar2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editNewPar3_Callback(hObject, eventdata, handles)
% hObject    handle to editNewPar3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editNewPar3 as text
%        str2double(get(hObject,'String')) returns contents of editNewPar3 as a double

% --- Executes during object creation, after setting all properties.
function editNewPar3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editNewPar3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editNewPar4_Callback(hObject, eventdata, handles)
% hObject    handle to editNewPar4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editNewPar4 as text
%        str2double(get(hObject,'String')) returns contents of editNewPar4 as a double

% --- Executes during object creation, after setting all properties.
function editNewPar4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editNewPar4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editNewPar5_Callback(hObject, eventdata, handles)
% hObject    handle to editNewPar5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editNewPar5 as text
%        str2double(get(hObject,'String')) returns contents of editNewPar5 as a double

% --- Executes during object creation, after setting all properties.
function editNewPar5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editNewPar5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function editFittingResult_Callback(hObject, eventdata, handles)
% hObject    handle to editFittingResult (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editFittingResult as text
%        str2double(get(hObject,'String')) returns contents of editFittingResult as a double

% --- Executes during object creation, after setting all properties.
function editFittingResult_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editFittingResult (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in startfitting.
function startfitting_Callback(hObject, eventdata, handles)
% hObject    handle to startfitting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.flag_fitting = 1;
PAR(1) = handles.pardata.par1;
PAR(2) = handles.pardata.par2;
PAR(3) = handles.pardata.par3;
PAR(4) = handles.pardata.par4;
PAR(5) = handles.pardata.par5;
lb = [ handles.pardata.par1lb, handles.pardata.par2lb, ...
    handles.pardata.par3lb, handles.pardata.par4lb,...
    handles.pardata.par5lb ];
ub = [ handles.pardata.par1ub, handles.pardata.par2ub, ...
    handles.pardata.par3ub, handles.pardata.par4ub,...
    handles.pardata.par5ub ];

fittingoption.TolFun  = handles.fittingoption.TolFun;
fittingoption.MaxFunEvals = handles.fittingoption.MaxFunEvals;

ADAT = handles.selectedADAT;
BDAT = handles.selectedBDAT;
 
[XB_DATA CB_DATA FitResult x ...
    resnorm residual exitflag output] =  ...
    SIMSUnifitN0(ADAT,BDAT,PAR,lb,ub,fittingoption); 
 
handles.pardata.newpar1 = x(1);
handles.pardata.newpar2 = x(2);
handles.pardata.newpar3 = x(3);
handles.pardata.newpar4 = x(4);
handles.pardata.newpar5 = x(5);

handles.pardata.miglength = x(4);
handles.pardata.width = x(5);

axes(handles.axesaf)
h = zeros(2, 1);
h(1) = semilogy(XB_DATA,FitResult,'r');
hold on
h(2) = semilogy(XB_DATA,CB_DATA,'b+');
legend(h, 'Fitted Line', 'SIMS Data');
hold off
box on
handles.pardata.miglength = x(4);
handles.pardata.width = x(5);
sbuff1 = strcat('Fitted Mig. Length:  ',num2str(handles.pardata.miglength));
sbuff2 = strcat('Fitted Width      :  ',num2str(handles.pardata.width));
offset = 0.02;
text(0.3*max(XB_DATA),0.8*max(CB_DATA),sbuff1,'FontSize',12);
text(0.3*max(XB_DATA),0.3*max(CB_DATA),sbuff2,'FontSize',12);

xlabel('SIMS Depth ($$\mathrm{\AA}$$)','Interpreter','latex');
ylabel('SIMS Doping Concentration');
handles.fitinfo.fitresult = FitResult;
handles.fitinfo.xb_data = XB_DATA;
handles.fitinfo.cb_data = CB_DATA;
sbuff1 = num2str(handles.pardata.newpar1);
sbuff2 = num2str(handles.pardata.newpar2);
sbuff3 = num2str(handles.pardata.newpar3);
sbuff4 = num2str(handles.pardata.newpar4);
sbuff5 = num2str(handles.pardata.newpar5);

set(handles.editNewPar1,'String',sbuff1,...
    'Value',1);
set(handles.editNewPar2,'String',sbuff2,...
    'Value',1);
set(handles.editNewPar3,'String',sbuff3,...
    'Value',1);
set(handles.editNewPar4,'String',sbuff4,...
    'Value',1);
set(handles.editNewPar5,'String',sbuff5,...
    'Value',1);

handles.fittingresult.resnorm  = resnorm;
handles.fittingresult.output  = output;

sbuff = strvcat('resnorm(sum{(fun(x,xdata)-ydata).^2}) =', ...
    num2str(handles.fittingresult.resnorm,'%10.4e\n'),...
    handles.fittingresult.output.message);
set(handles.editFittingResult,'String',sbuff,...
    'Value',1);

sbuff = strcat('SIMS_', ...
    handles.simsdataset(handles.selectedDSidx).WPInfo,'_',...
    handles.simsdataset(handles.selectedDSidx).AnnTemptInfo,'_',...
    handles.simsdataset(handles.selectedDSidx).DataSetInfo,'_', ...
    'WInfo.log');
sbuff = strcat('./FittingDB/',sbuff);
fid = fopen(sbuff,'r+');
if (fid == -1)
    smsg = strcat('Creating New WInfo file: ',sbuff);
    msgbox(smsg)
    fid = fopen(sbuff,'w');
    WInfoAT{1} = handles.selectedAnnealTime;
    WInfo(1) = handles.pardata.width;
else
    scomment = fgetl(fid);
    i = 1;
    while 1
        tline = fgetl(fid);
        if ~ischar(tline), break, end
        [sbuff rem] = strtok(tline,' ');
        WInfoAT{i} = sbuff;
        WInfo(i) = str2num(rem);
        i = i + 1;
        imax = i;
    end

    flgWExist = 0;
    sVal = str2num(strtok(handles.selectedAnnealTime,'s'));
    if (sVal == 0)
        sAnnealT = 'AsGrown';
    else
        sAnnealT = handles.selectedAnnealTime;
    end
    for j = 1:length(WInfo)
        if (findstr(sAnnealT,WInfoAT{j}))
            WInfoAT{j} = sAnnealT;
            WInfo(j) = handles.pardata.width;
            flgWExist = 1;
        end
    end
    if (flgWExist ~= 1)
        WInfoAT{imax} = handles.selectedAnnealTime;
        WInfo(imax) = handles.pardata.width;

        % Note: Sorting the annealing time
        for idxAF=1:length(WInfo)
            for jdxAF=1:length(WInfo)-1
                [svaljdxAF rem]=  strtok(WInfoAT{jdxAF},'s');
                [svaljdxAF1 rem]=  strtok(WInfoAT{jdxAF+1},'s');
                if ( str2num(svaljdxAF) > ...
                        str2num(svaljdxAF1) )
                    temp = WInfoAT{jdxAF};
                    WInfoAT{jdxAF} = ...
                        WInfoAT{jdxAF+1};
                    WInfoAT{jdxAF+1} = temp;
                    temp = WInfo(jdxAF);
                    WInfo(jdxAF) = ...
                        WInfo(jdxAF+1);
                    WInfo(jdxAF+1) = temp;
                end
            end
        end
    end
end
frewind(fid);
fprintf(fid, '%s \n', '# Data Set ?? W0 W1 ... from fitting');

for i=1:length(WInfo)
    fprintf(fid, '%s %f \n', WInfoAT{i}, WInfo(i));
end
fclose(fid);
guidata(hObject,handles)

% --- Executes on button press in pushbuttonPlotBF.
function pushbuttonPlotBF_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonPlotBF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sbuff = strcat('./FittingDB/',handles.selectedANFN,'_BeforeFitting');
figure('FileName',sbuff)
ADAT = handles.selectedADAT;
ADAT(:,2) = ADAT(:,2) + 1e10;
XA = ADAT(:,1);
CA = ADAT(:,2);
h = zeros(2,1);
h(1) = semilogy(XA,CA,'b');
hold on
BDAT =handles.selectedBDAT ;
BDAT(:,2) = BDAT(:,2) + 1e10;
XB_DATA = BDAT(:,1);
CB_DATA = BDAT(:,2);
h(2) = semilogy(XB_DATA,CB_DATA,'b+');
legend(h, 'As Grown', 'After Annealing');
xlabel('SIMS Depth ($$\mathrm{\AA}$$)','Interpreter','latex');
ylabel('SIMS Doping Concentration');
title('Before fitting')
hold off

% --- Executes on button press in pushbuttonPlotAF.
function pushbuttonPlotAF_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonPlotAF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if (handles.flag_fitting == 1)
sbuff = strcat('./FittingDB/',handles.selectedANFN,'_AfterFitting');
figure('FileName',sbuff)
h = zeros(2,1);
h(1) = semilogy(handles.fitinfo.xb_data,handles.fitinfo.fitresult,'r');
hold on
h(2) = semilogy(handles.fitinfo.xb_data,handles.fitinfo.cb_data,'b+');
legend(h, 'As Grown', 'After Annealing');
hold off
box on
xlabel('SIMS Depth ($$\mathrm{\AA}$$)','Interpreter','latex');
ylabel('SIMS Doping Concentration');
title('After fitting')
sbuff1 = strcat('Fitted Mig. Length: ',num2str(handles.pardata.miglength));
sbuff2 = strcat('Fitted Width         : ',num2str(handles.pardata.width));
offset = 0.02;
text(0.3*max(handles.fitinfo.xb_data), ...
    0.8*max(handles.fitinfo.cb_data),sbuff1,'FontSize',12);
text(0.3*max(handles.fitinfo.xb_data), ...
    0.3*max(handles.fitinfo.cb_data),sbuff2,'FontSize',12);

hold off
else
    errordlg('   No fitting is done yet', 'Error');
end
