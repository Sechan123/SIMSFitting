function [XB_DATA CB_DATA FitResult x ...
    resnorm residual exitflag output ] = ...
    SIMSUnifitN0(ADAT, BDAT, PAR, lb, ub, fittingoption)
global NA NB NI
global XB_DATA

NP = length(PAR);
DX = 5.0;

ADAT(:,2) = ADAT(:,2) + 1e10;
XA = ADAT(:,1);
CA = ADAT(:,2);
BDAT(:,2) = BDAT(:,2) + 1e10;
XB_DATA = BDAT(:,1);
CB_DATA = BDAT(:,2);
NA = length(XA);
NB = length(XB_DATA);
XMAX = XA(NA);
NI = floor(XMAX/DX)+1;

% Scan through grid
X = zeros(1,NI);
A = zeros(1,NI);
for I=1:NI
    X(I) = (I)*DX;
    K = 2;
    while (XA(K) <= X(I) && K <= NA)
        K = K + 1;
        if (K > NA)
            break;
        end
    end
    if (K <= NA)
        %   For each grid point, find the SIMS data point just ahead.
        %   Interpolate between this SIMS point and the previous one.
        if(XA(K) > X(I))
            A(I) = CA(K) + ...
                (CA(K-1)-CA(K))*(X(I)-XA(K))/(XA(K-1)-XA(K));
        elseif (K == NA)
            A(I) = 0;
        end
    end
end

options = optimset('Display','off',...
    'TolFun', fittingoption.TolFun,...
    'MaxFunEvals',fittingoption.MaxFunEvals);
% Universal Fit
[x,resnorm,residual,exitflag,output] = ...
    lsqcurvefit(@myfun,PAR,A,CB_DATA,lb,ub,options);

FitResult = myfun(x,A);

function F = myfun(PAR,A)
DOFFSET = 1000.0;
DX = 5.0;

IFLAG = 0;
global XB_DATA
global NA NB NI
for I=1:NI
    X(I) = I*DX;
end
%      X-axis offset and scaling factor for profile B
%      DOFFSET     Depth `origin' about which the x-axis is to be stretched
%                  by the amount MULXB
%      MULXB       X-axis stretch factor
MULXB=PAR(2);
OFFXB=PAR(1)-(MULXB-1.0)*DOFFSET;
%      Concentration scaling factor for profile B
MULCB=PAR(3);
%      Migration length parameter
LAMBDA=PAR(4);
%      Diffusion width parameter W= sqrt(8*D*t) = lambda*sqrt(8*theta)
W=PAR(5);
THETA=(W/LAMBDA)^2/8.0;
%      Evaluate diffusion function in the range 0 to 2*XMAX
%      in discretized form, and store as array unifun.
for IDIF = 1:2*NI+1
    UNIFUN(IDIF)=UNIVERSAL((IDIF-1)*DX/LAMBDA,THETA);
end
%      Convolute as-grown data with discretised function
G = zeros(1,NI);
for I=1:NI
    G(I) = (A(I)/MULCB)*exp(-THETA);
    for J=1:NI
        G(I) = G(I) + (A(J)/MULCB)*DX/LAMBDA ...
            *( UNIFUN(abs(I-J)+1) + UNIFUN(abs(I+J)+1) );
    end
end
%      Output convergence warning if NMAX was too small.
%      This was checked in function UNIVERSAL (IFLAG = 0 or 1).
%
if (IFLAG == 1)
    disp(' *** NMAX too small for convergence ***')
end
% C     Interpolate profile (X,G) onto grid B (XB,CBFIT)
% C     for comparison with data profile (XB,CB)
%
% C     Scan through grid
%
for I=1:NB
    K = 2;
    while ((X(K)-OFFXB)/MULXB <= XB_DATA(I) && K ~= NI)
        K = K + 1;
        if (K > NA + 1)
            disp('Interpolation error')
        end
    end
    % For each SIMS data point, find the convolution grid point just ahead.
    % Interpolate between this convolution grid point and the previous one.
    if ((X(K)-OFFXB)/MULXB > XB_DATA(I))
        CBFIT(I) = G(K) + ...
            (G(K-1)-G(K))*(XB_DATA(I)-(X(K)-OFFXB)/MULXB)...
            /((X(K-1)-OFFXB)/MULXB-(X(K)-OFFXB)/MULXB);
    elseif (K == NI)
        CBFIT(I) = 0.0;
    end
end
F = CBFIT';

function UNIVERSAL = UNIVERSAL(x,t)
% C     Calculate terms of universal s function up to n=nmax
%
iflag = 0;
tlimit = 50.0;
if (t < tlimit)
    nmax = floor(4.0*t);
else
    disp('theta exceeds ')
    disp('increase nmax in function universal(x,t)')
end
%
%      Evaluate ln(n!) as an array in n to save repetition.
%      Array is called facl(n), function is called factl(n).

n = 0;
while n <= 2*nmax
    facl1(n+1) = factl(n);
    n = n+1;
end
sum = 0.0;
n = 1;
while n <= nmax
    term = Pn(n,facl1,t)*fn(n,facl1,x);
    sum = sum + term;
    % C       Convergence criterion
    if (sum > 0.0)
        if(abs(term/sum) < 1.0e-6)
            break;
        end
    end
    if ((sum <= 0.0) && ( n == nmax))
        break;
    end
    n = n + 1;
    if ( n == nmax)
        iflag = 1;
    end
end
UNIVERSAL = sum;

function factl = factl(n)
%      Called by function 'universal'.
%      Evaluates ln(n!) as a floating-point number
%      by summing logs instead of multiplying numbers.
%
sum = 0;
k   = 1;
while (k <= n)
    sum = sum + log(k);
    k = k + 1;
end
factl = sum;

function Pn = Pn(n,facl1,t)
%      Called by function 'universal'
%      Evaluates value of Psubn(t)
%
Pn = exp(-t + log(t)*n - facl1(n+1));

function fn = fn(n,facl1,x)
%      Called by function 'universal'
%      Evaluates value of fsubn(x)
fn = 0.0;
k   = 0;
while (k <= n-1)
    if ((x ~= 0.0) || (k < 0))
        if ((x <= 0.0) && (k==0))
            xkl = 0.0;
        else
            xkl = log(x)*k;
        end
        itop = 2*n-2-k;
        ibot = n-1;
        fn = fn + ...
            exp(-x+log(2.)*(k+1-2*n)-facl1(k+1)...
            +combil(itop,ibot,facl1)+xkl);
    end
    %        Trap for ln(x) where x=0. and k > 0
    %        in which case the term in the sum is zero
    k = k + 1;
end

function combil = combil(i,j,facl1)
% C     Called by function 'fn'
% C     Calculates log-e of the combinatorial ( i )

combil = facl1(i+1) - facl1(i-j+1) - facl1(j+1);

